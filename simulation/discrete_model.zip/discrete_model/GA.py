import numpy as np
import datetime
from abc import abstractmethod
from matplotlib import pyplot as plt
import os


class GA:
    def __init__(self, fitness_func, n_dim, selection_func, crossover_func, mutation_func,
                 population, size_pop=50, max_iter=200, prob_mut=0.01, prob_crossover=0.5):
        # 属性
        self.fitness_func = fitness_func
        self.n_dim = n_dim
        self.selection = selection_func
        self.crossover = crossover_func
        self.mutation = mutation_func
        self.size_pop = size_pop
        self.max_iter = max_iter + 1  # 第一轮为启动，不算
        self.prob_mut = prob_mut
        self.prob_crossover = prob_crossover

        # 当代信息
        self.population = np.array(population)
        self.fitness = []
        self.feasible = []
        self.base = 0
        self.generation_best_individual = []
        self.generation_best_fitness = []

        # 历史信息
        self.all_history_fitness = []
        self.best_individual = None
        self.best_fitness = None
    
    @abstractmethod
    def selection(self):
        pass

    @abstractmethod
    def crossover(self):
        pass

    @abstractmethod
    def mutation(self):
        pass

    def run(self):
        start_time = datetime.datetime.now()
        start_time_str = start_time.strftime('%Y-%m-%d %H:%M:%S')
        last_best_fitness = self.base
        cnt = 1

        for i in range(self.max_iter):
            if cnt == 20:
                print('Early Stop!!')
                break
            print('This is the %dth generation.' % i)
            # 记录不可行解的个数
            self.fitness = self.fitness_func(self.population)

            # 记录当前种群信息
            generation_best_index = self.fitness.index(max(self.fitness))
            self.generation_best_individual.append(self.population[generation_best_index])
            self.generation_best_fitness.append(self.fitness[generation_best_index])
            if abs(self.fitness[generation_best_index] - last_best_fitness) < 300:
                cnt += 1
            else:
                last_best_fitness = self.fitness[generation_best_index]
                cnt = 1
            print('当前种群最优解为：')
            print(self.generation_best_individual[-1])
            print(self.generation_best_fitness[-1])

            # 更新历史信息
            self.all_history_fitness.append(self.fitness)

            # 种群进化
            self.selection(self)
            self.crossover(self)
            self.mutation(self)

        global_best_index = self.generation_best_fitness.index(max(self.generation_best_fitness))
        global_best_individual = self.generation_best_individual[global_best_index]
        global_best_fitness = self.generation_best_fitness[global_best_index]

        # 输出记录信息
        end_time = datetime.datetime.now()
        end_time_str = end_time.strftime('%Y-%m-%d %H:%M:%S')
        folder = 'Result/' + end_time.strftime('%Y%m%d%H%M%S') + '/'
        executive_minute = (end_time - start_time).seconds / 60
        os.makedirs(folder)
        with open(folder+'iteration_information.txt', 'w') as fout:
            fout.write('开始时间为：%s, 结束时间为：%s，用时：%f分钟\n' % (start_time_str, end_time_str, executive_minute))

            for i in range(self.max_iter):
                fout.write('第%d轮\n' % i)
                fout.write('[')
                for j in range(self.n_dim):
                    fout.write(str(self.generation_best_individual[i][j]))
                    if j < self.n_dim - 1:
                        fout.write(',')
                fout.write(']\n')
                fout.write('目标函数为：%f\n' % self.generation_best_fitness[i])

            fout.write('最佳个体：\n')
            fout.write('[')
            for j in range(self.n_dim):
                fout.write((str(global_best_individual[j])))
                if j < self.n_dim-1:
                    fout.write(',')
            fout.write(']\n')
            fout.write('适应度值为：%f\n' % global_best_fitness)

        # 遗传曲线
        x = [i for i in range(self.max_iter)]
        plt.plot(x, self.generation_best_fitness)
        plt.title('Evolutionary Curve')
        plt.xlabel('Generation')
        plt.ylabel('Fitness value')
        plt.savefig(folder + 'Evolutionary_curve.png')
        return global_best_individual, global_best_fitness, folder