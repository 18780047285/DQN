def decode_P_policy(action, env):
    index = 0
    t2g_probs = {}
    while index < len(action):
        for c in env.customer_nodes:
            t2g_probs[c] = []
            for s in env.structure.G[c]:
                t2g_probs[c].append(action[index])
                index += 1
        