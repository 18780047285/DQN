import torch
import torch.nn as nn
import torch.optim as optim
from torch.nn import functional as F
from torch.distributions import Categorical
import numpy as np
from itertools import count

from nets import TestNet
from decode import decode_P_policy

class PG_Policy:

    def __init__(self, n_state, n_action, env, raw_policy, gamma, batch_size, log_interval):
        self.policy = TestNet(n_action, n_state, 10)
        self.n_action = n_action
        self.n_state = n_state
        self.env = env
        self.raw_t2g = raw_policy['t2g']
        self.raw_g2t = raw_policy['g2t']
        self.optimizer = optim.Adam(self.policy.parameters(), lr=1e-2)
        self.gamma = gamma
        self.eps = np.finfo(np.float64).eps.item()
        self.batch_size = batch_size
        self.log_interval = log_interval
    
    def select_action(self, state):
        state = torch.from_numpy(state).float().unsqueeze(0)
        probs = self.policy(state)
        
        t2g_probs = probs[].view(2, 2, )
        m = Categorical(probs)
        action = m.sample()
        self.policy.saved_log_probs.append(m.log_prob(action))
        return action.item()
    
    def finish_episode(self):
        R = 0
        policy_loss = []
        returns = []
        for r in self.policy.rewards[::-1]:
            R = r + self.gamma * R
            returns.insert(0, R)
        returns = torch.tensor(returns)
        returns = (returns - returns.mean()) / (returns.std() + eps)
        for log_prob, R in zip(self.policy.saved_log_probs, returns):
            policy_loss.append(-log_prob * R)
        self.optimizer.zero_grad()
        policy_loss = torch.cat(policy_loss).sum()
        policy_loss.backward()
        self.optimizer.step()
        del self.policy.rewards[:]
        del self.policy.saved_log_probs[:]
 
    def run(self, env):
        running_reward = -10
        for i_episode in count(1):
            state = self.env.reset()
            while self.env.t < self.env.T: 
                action = self.select_action(state)
                self.env.change_params(action)
                for t in range(self.batch_size):
                    self.env.step(batch=True)
                ep_reward = -env.performance_evaluation()
                reward = -env.performance_evaluation(self.batch_size)
                self.policy.rewards.append(reward)
            running_reward = 0.05 * ep_reward + (1 - 0.05) * running_reward
            self.finish_episode()
            if i_episode % self.log_interval == 0:
                print('Episode {}\tLast reward: {:.2f}\tAverage reward: {:.2f}'.format(
                    i_episode, ep_reward, running_reward))
            if running_reward > 0:
                print("Solved! Running reward is now {} and "
                    "the last episode runs to {} time steps!".format(running_reward, t))
                torch.save(self.policy.state_dict(),'hello.pt')
                break


