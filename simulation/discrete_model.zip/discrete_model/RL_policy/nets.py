import torch
import torch.nn as nn
from torch.nn import functional as F

class TestNet(nn.Module):

    def __init__(self, n_action, n_state, n_hidden):
        super(TestNet, self).__init__()
        self.linear1 = nn.Linear(n_state, n_hidden)
        self.hidden = nn.Linear(n_hidden, n_action)
        self.softmax = nn.Softmax(dim=0)
        self.saved_log_probs = []
        self.rewards = []

    def forward(self, state, action):
        x = self.linear1(state)
        x = F.relu(x)
        action_scores = self.hidden(x)
        # x = F.relu(x)
        return self.softmax(action_scores)

    