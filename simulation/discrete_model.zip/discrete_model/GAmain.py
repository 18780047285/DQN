from os import cpu_count
from GA import GA
from queue_system import QueueSystem, INF
from dataprep import read_data
from data_parcser import CallCenterStrcut
from PT_policy.SP_test_policy import generate, decode
from P_policy.SP_test_policy import TYPE2GROUP, GROUP2TYPE
import numpy as np
from multiprocessing import Pool, cpu_count

struct_data= read_data('single_pool')
CCS = CallCenterStrcut()
CCS.build_general_design(struct_data)

def fitness_func(ind):
    y = decode(ind)
    queue = QueueSystem(36000, INF, CCS, 'PT', 1000, 0, 0, GROUP2TYPE, TYPE2GROUP, idle_agent_threshold_table=y)
    queue.run()
    fitness = queue.total_SL[-1]
    return fitness

def fitness_func_parallel(x):
    pool = Pool(cpu_count())
    res = pool.map(fitness_func, x)
    return res

def selection(algorithm):
    fitness = algorithm.fitness
    aspirants_index = np.random.choice(range(algorithm.size_pop), size=2)
    return max(aspirants_index, key=lambda j:fitness[j])

def crossover_1point(i, algorithm):
    pop, size_pop, len_chrom = algorithm.population, algorithm.size_pop, algorithm.n_dim
    alpha = 0.6
    n = np.random.randint(0, len_chrom - 1, 1)[0]
    seg1, seg2 = algorithm.population[i, n:], algorithm.population[i+1, n:]
    seg1, seg2 = alpha*seg1 +(1 - alpha)*seg2, alpha*seg2 +(1 - alpha)*seg1
    algorithm.population[i, n:], algorithm.population[i+1, n:] = seg2, seg1
    return algorithm.population[i, i+2]

def crossover(algorithm):
    size_pop = algorithm.size_pop
    for i in range(0, size_pop-1, 2):
        res = crossover_1point(i, algorithm)
        algorithm.population[i, i+2] = res

def mutation_1point(i, algorithm, mask):
    if not mask[i]:
        return algorithm.population[i]
    n = np.random.randint(0, algorithm.n_dim, 1)[0]
    algorithm.population[i][n] = np.random.uniform(0, 5, 1)[0]
    return algorithm.population[i]

def mutation(algorithm):
    size_pop = algorithm.size_pop
    mask = (np.random.rand(algorithm.size_pop, 1) < algorithm.prob_mut)
    for i in range(size_pop):
        res = mutation_1point(i, algorithm, mask)
        algorithm.population[i] = res
    

if __name__ == '__main__':
    population = generate(50)
    algGA = GA(fitness_func_parallel, 16, selection, crossover, mutation, population, size_pop=50, max_iter=100)
    best_ind, best_fitness, _ = algGA.run()
