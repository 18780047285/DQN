from PT_policy.Xdesign_test_policy import IDLE_AGENT_THRESHOLD
from queue_system import QueueSystem, INF
from dataprep import read_data
from data_parcser import CallCenterStrcut
from P_policy.SP_test_policy import TYPE2GROUP, GROUP2TYPE
from PT_policy.SP_test_policy import generate
from tqdm import tqdm

def run(design_name):
    struct_data= read_data(design_name)
    CCS = CallCenterStrcut()
    CCS.build_general_design(struct_data)
    best = 0
    individuals = generate(500)
    for i in tqdm(range(500)):
        IDLE_AGENT_THRESHOLD = individuals[i]
        test_queue = QueueSystem(36000, INF, CCS, 'PT', 1000, 3600, 9, GROUP2TYPE,
                                TYPE2GROUP, idle_agent_threshold_table=IDLE_AGENT_THRESHOLD)
    # test_queue = QueueSystem(36000, INF, CCS, 'PT', 1000, 0, 20, 80, 0, GROUP2TYPE, 
    #                          TYPE2GROUP, TIME_DELAY_TABLE, IDLE_AGENT_THRESHOLD)
        PE = test_queue.run()
        if PE > best:
            print('best update %f -> %f' % (best, PE))
            best = PE
    return best
if __name__ == "__main__":
    PE = run('single_pool')  
    print(PE)   