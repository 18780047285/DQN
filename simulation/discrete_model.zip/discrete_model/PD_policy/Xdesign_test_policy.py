TIME_DELAY_TABLE = {'s1': {'c1': 8, 'c2': 1}, 's2': {'c1': 4, 'c2': 6}}

if __name__ == "__main__":
    pass