import numpy as np

def generate_solution(num, lb, ub):
    solutions = np.random.randint(lb, ub, (num, 4))
    return solutions

if __name__ == "__main__":
    pass