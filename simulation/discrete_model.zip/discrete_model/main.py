from queue_system import QueueSystem, INF
from dataprep import read_data
from data_parcser import CallCenterStrcut
from P_policy.SP_test_policy import TYPE2GROUP, GROUP2TYPE
from PD_policy.Xdesign_test_policy import TIME_DELAY_TABLE
from PT_policy.SP_test_policy import IDLE_AGENT_THRESHOLD

def run(design_name):
    struct_data= read_data(design_name)
    CCS = CallCenterStrcut()
    if design_name == 'Ndesign':
        CCS.build_Ndesign(struct_data)
    elif design_name == 'Xdesign':
        CCS.build_Xdesign(struct_data)
    elif design_name == 'Wdesign':
        CCS.build_Wdesign(struct_data)
    else:
        CCS.build_general_design(struct_data)
    # test_queue = QueueSystem(36000, INF, CCS, 'g', 1000, 3600, 9)
    # test_queue = QueueSystem(360000, INF, CCS, 'P', 1000, 3600, 20, 80, 9, GROUP2TYPE, TYPE2GROUP)
    # test_queue = QueueSystem(360000, INF, CCS, 'PD', 1000, 3600, 20, 80, 9, GROUP2TYPE, TYPE2GROUP, TIME_DELAY_TABLE)
    test_queue = QueueSystem(36000, INF, CCS, 'PT', 1000, 3600, 9, GROUP2TYPE,
                             TYPE2GROUP, idle_agent_threshold_table=IDLE_AGENT_THRESHOLD)
    # test_queue = QueueSystem(36000, INF, CCS, 'PT', 1000, 0, 20, 80, 0, GROUP2TYPE, 
    #                          TYPE2GROUP, TIME_DELAY_TABLE, IDLE_AGENT_THRESHOLD)
    PE = test_queue.run(plot=True)
    return PE
if __name__ == "__main__":
    PE = run('single_pool')     