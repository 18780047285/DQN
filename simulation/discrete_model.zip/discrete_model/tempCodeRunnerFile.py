test_queue = QueueSystem(360000, INF, CCS, 'PDT', 1000, 3600, 20, 80, 9, GROUP2TYPE, 
                             TYPE2GROUP, TIME_DELAY_TABLE, IDLE_AGENT_THRESHOLD)