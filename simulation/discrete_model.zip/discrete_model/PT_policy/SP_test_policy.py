import numpy as np
IDLE_AGENT_THRESHOLD = {'c1': {'s1': 2.9, 's6': 0.8}, 
                        'c2': {'s2': 2.9, 's6': 0.5},
                        'c3': {'s3': 1.3, 's6': 0.6},
                        'c4': {'s4': 2.9, 's6': 0.7},
                        'c5': {'s5': 2.9, 's6': 0.9},
                        'c6': {'s6': 2.9, 's1': 0.4, 's2': 0.56, 's3': 0.63, 's4': 0.8, 's5': 0.5}}


def generate(num):
    x =  np.random.uniform(0, 5, size=(num, 16))
    return x

def decode(x):
    ind = {'c1': {'s1': x[0], 's6': x[1]}, 
            'c2': {'s2': x[2], 's6': x[3]},
            'c3': {'s3': x[4], 's6': x[5]},
            'c4': {'s4': x[6], 's6': x[7]},
            'c5': {'s5': x[8], 's6': x[9]},
            'c6': {'s6': x[10], 's1': x[11], 's2': x[12], 's3': x[13], 's4': x[14], 's5': x[15]}}
    return ind

if __name__ == '__main__':
    num = 3
    individuals = generate(num)
    print(individuals)