IDLE_AGENT_THRESHOLD = {'c1': {'s1': 0.3, 's2': 0.1}, 'c2': {'s1': 4.5, 's2': 0.5}}
