def F_s(SL, threshold):
    return sum([(max(threshold[c] - SL[c]*100, 0))**2 for c in SL.keys()])

if __name__ == "__main__":
    pass