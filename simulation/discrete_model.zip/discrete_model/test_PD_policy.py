from PD_policy.Xdesign_random_policy import generate_solution
from queue_system import QueueSystem, INF
from dataprep import read_data
from data_parcser import CallCenterStrcut
from P_policy.Xdesign_test_policy import TYPE2GROUP, GROUP2TYPE
from PD_policy.Xdesign_test_policy import TIME_DELAY_TABLE

solutions = generate_solution(100, 0, 15)
struct_data= read_data('Xdesign')
CCS = CallCenterStrcut()
CCS.build_Xdesign(struct_data)
best_PE = INF
best_sol = {}
for i in solutions:
    time_delay_table = {'s1': {'c1': i[0], 'c2': i[1]}, 's2': {'c1': i[2], 'c2': i[3]}}
    test_queue = QueueSystem(360000, INF, CCS, 'PD', 1000, 3600, 20, 80, 9, GROUP2TYPE, TYPE2GROUP, time_delay_table)
    PE = test_queue.run()
    if PE < best_PE:
        best_PE = PE
        best_sol = time_delay_table
print('PE: ', best_PE)
print('best solution: ', best_sol)
    