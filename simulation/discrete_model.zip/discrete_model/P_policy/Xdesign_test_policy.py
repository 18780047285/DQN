TYPE2GROUP = {'c1': [0, 1], 'c2': [1, 0]}
GROUP2TYPE = {'s1': [0, 1], 's2': [1, 0]}

if __name__ == "__main__":
    pass